plugins {
    id("com.android.application") version "8.5.0" apply false  // Update from 8.4.0
    id("org.jetbrains.kotlin.android") version "1.9.0" apply false
}