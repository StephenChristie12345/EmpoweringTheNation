package com.example.empoweringnation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.ttsco.R

class CourseAdapter(private val courses: List<Course>) : RecyclerView.Adapter<CourseAdapter.CourseViewHolder>() {

    class CourseViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val cardView: CardView = view.findViewById(R.id.courseCard)
        val titleText: TextView = view.findViewById(R.id.courseTitle)
        val priceText: TextView = view.findViewById(R.id.coursePrice)
        val descriptionText: TextView = view.findViewById(R.id.courseDescription)
        val modulesText: TextView = view.findViewById(R.id.courseModules)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CourseViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_course, parent, false)
        return CourseViewHolder(view)
    }

    override fun onBindViewHolder(holder: CourseViewHolder, position: Int) {
        val course = courses[position]

        holder.titleText.text = course.title
        holder.priceText.text = "R${course.price}"
        holder.descriptionText.text = course.description
        holder.modulesText.text = course.modules.joinToString("\n") { "• $it" }

        // Set card background color based on course
        val colorRes = when (course.id) {
            "first-aid" -> R.color.course_yellow
            "sewing" -> R.color.course_blue
            "landscaping" -> R.color.course_green
            "life-skills" -> R.color.course_orange
            "child-minding" -> R.color.course_yellow
            "cooking" -> R.color.course_red
            else -> R.color.course_blue
        }

        holder.cardView.setCardBackgroundColor(ContextCompat.getColor(holder.itemView.context, colorRes))
    }

    override fun getItemCount() = courses.size
}
