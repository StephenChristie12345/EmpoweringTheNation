package com.example.empoweringnation

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import android.widget.TextView
import com.example.ttsco.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        findViewById<CardView>(R.id.cardAbout).setOnClickListener {
            startActivity(Intent(this, AboutActivity::class.java))
        }

        findViewById<CardView>(R.id.cardSixMonth).setOnClickListener {
            startActivity(Intent(this, SixMonthCoursesActivity::class.java))
        }

        findViewById<CardView>(R.id.cardSixWeek).setOnClickListener {
            startActivity(Intent(this, SixWeekCoursesActivity::class.java))
        }

        findViewById<CardView>(R.id.cardCalculator).setOnClickListener {
            startActivity(Intent(this, FeeCalculatorActivity::class.java))
        }
    }
}
