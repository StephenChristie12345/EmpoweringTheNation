package com.example.empoweringnation

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ttsco.R

class FeeCalculatorActivity : AppCompatActivity() {
    private lateinit var recyclerViewSixMonth: RecyclerView
    private lateinit var recyclerViewSixWeek: RecyclerView
    private lateinit var totalAmountText: TextView
    private lateinit var sixMonthAdapter: FeeCalculatorAdapter
    private lateinit var sixWeekAdapter: FeeCalculatorAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fee_calculator)

        setupToolbar()
        setupRecyclerViews()
        updateTotalAmount()
    }

    private fun setupToolbar() {
        val toolbar = findViewById<Toolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Fee Calculator"

        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }
    }

    private fun setupRecyclerViews() {
        totalAmountText = findViewById(R.id.totalAmountText)

        // 6-Month courses
        recyclerViewSixMonth = findViewById(R.id.recyclerViewSixMonth)
        sixMonthAdapter = FeeCalculatorAdapter(CourseData.sixMonthCourses.toMutableList()) {
            updateTotalAmount()
        }
        recyclerViewSixMonth.layoutManager = LinearLayoutManager(this)
        recyclerViewSixMonth.adapter = sixMonthAdapter

        // 6-Week courses
        recyclerViewSixWeek = findViewById(R.id.recyclerViewSixWeek)
        sixWeekAdapter = FeeCalculatorAdapter(CourseData.sixWeekCourses.toMutableList()) {
            updateTotalAmount()
        }
        recyclerViewSixWeek.layoutManager = LinearLayoutManager(this)
        recyclerViewSixWeek.adapter = sixWeekAdapter
    }

    private fun updateTotalAmount() {
        val sixMonthTotal = sixMonthAdapter.getSelectedCourses().sumOf { it.price }
        val sixWeekTotal = sixWeekAdapter.getSelectedCourses().sumOf { it.price }
        val total = sixMonthTotal + sixWeekTotal

        totalAmountText.text = "R$total"

        val selectedCount = sixMonthAdapter.getSelectedCourses().size + sixWeekAdapter.getSelectedCourses().size
        val subtitleText = findViewById<TextView>(R.id.totalSubtitleText)
        subtitleText.text = if (total == 0) {
            "Select courses to see pricing"
        } else {
            "Total for $selectedCount course(s)"
        }
    }
}