package com.example.empoweringnation

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.ttsco.R

class FeeCalculatorAdapter(
    private val courses: MutableList<Course>,
    private val onSelectionChanged: () -> Unit
) : RecyclerView.Adapter<FeeCalculatorAdapter.FeeCalculatorViewHolder>() {

    class FeeCalculatorViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val courseText: TextView = view.findViewById(R.id.courseText)
        val checkBox: CheckBox = view.findViewById(R.id.courseCheckBox)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FeeCalculatorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_calculator_course, parent, false)
        return FeeCalculatorViewHolder(view)
    }

    override fun onBindViewHolder(holder: FeeCalculatorViewHolder, position: Int) {
        val course = courses[position]

        holder.courseText.text = "${course.title} - R${course.price}"
        holder.checkBox.isChecked = course.isSelected

        holder.checkBox.setOnCheckedChangeListener { _, isChecked ->
            course.isSelected = isChecked
            onSelectionChanged()
        }

        holder.itemView.setOnClickListener {
            holder.checkBox.isChecked = !holder.checkBox.isChecked
        }
    }

    override fun getItemCount() = courses.size

    fun getSelectedCourses(): List<Course> = courses.filter { it.isSelected }
}