package com.example.empoweringnation

data class Course(
    val id: String,
    val title: String,
    val price: Int,
    val description: String,
    val modules: List<String>,
    val duration: String,
    var isSelected: Boolean = false
)

object CourseData {
    val sixMonthCourses = listOf(
        Course(
            "first-aid",
            "First Aid",
            1500,
            "To provide first aid awareness and basic life support",
            listOf("Wounds and bleeding", "Burns and fractures", "Emergency scene and management", "CPR"),
            "6-Month"
        ),
        Course(
            "sewing",
            "Sewing",
            1500,
            "To provide alternations and new garment tailoring services",
            listOf("Types of stitches", "Threading a sewing machine", "Alterations", "Sewing buttons, zips, hems"),
            "6-Month"
        ),
        Course(
            "landscaping",
            "Landscaping",
            1500,
            "To provide landscaping services",
            listOf("Indigenous and exotic plants & trees", "Balancing and aesthetics in garden layouts", "Plant shapes, colours, layout design"),
            "6-Month"
        ),
        Course(
            "life-skills",
            "Life Skills",
            1500,
            "To provide skills for basic life management",
            listOf("Opening a bank account", "Basic labor law", "Basic literacy and numeracy"),
            "6-Month"
        )
    )

    val sixWeekCourses = listOf(
        Course(
            "child-minding",
            "Child Minding",
            750,
            "To provide basic child and baby care",
            listOf("Needs from birth to 1 year", "Toddler needs"),
            "6-Week"
        ),
        Course(
            "cooking",
            "Cooking",
            750,
            "To prepare nutritious family meals",
            listOf("Cooking techniques", "Nutritional requirements"),
            "6-Week"
        )
    )
}